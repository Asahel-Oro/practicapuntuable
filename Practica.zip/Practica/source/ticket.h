/*
 * ticket.h
 *
 *  Created on: Nov 2, 2019
 *      Author: Asahel Orozco B
 */

#ifndef TICKET_H_
#define TICKET_H_

extern int v;
extern void time_init(void);
extern void ticketime(double t1);
extern int increment(void);

#endif /* TICKET_H_ */
