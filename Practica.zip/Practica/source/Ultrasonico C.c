#include   <MKL25Z4.H>
#include   <stdio.h>
#include   <math.h>
#include   <stdlib.h>
#include   <Lcd.h>
#include   <ultrasonico.h>

int j;
float dist,dista,angulo,Vel=2;

unsigned short then = 0;
unsigned short now = 0;
unsigned short diff;

void init_ultra (void) {
	LCD_init();
	SIM->SCGC5 |= 0x2600;    /* enable clock to Port A,B,E */

	PORTE->PCR[22] = 0x0300; /* PUERTO DE PULSOS Port Used By TPM2 echo*/
	SIM->SCGC6 |= 0x04000000; /* enable clock to TPM2 */
	SIM->SOPT2 |= 0x01000000; /* use MCGFLLCLK as timer counter clock */
	TPM2->SC    = 0;          /* disable timer while configuring */
	TPM2->SC    = 0x07;       /* prescaler /128 */
	TPM2->MOD   = 0xFFFF;     /* max modulo value    65535 = FFFF*/
	TPM2->CONTROLS[0].CnSC = 0x0C; /* IC both edges */
	TPM2->SC    |= 0x08;      /* enable timer */

	PORTA->PCR[5]  = 0x100;  /* PUERTO DE .5PULSOS trigger*/
	PTA->PDDR     |= 0x20;
	//while(1){calculo();}
}
void calculo (void){
	while(!(TPM2->CONTROLS[0].CnSC & 0x80)) {PTA->PTOR = 0x20;}
	TPM2->CONTROLS[0].CnSC |= 0x80; /* clear CHF */
	now  = TPM2->CONTROLS[0].CnV;
	diff = now - then; /* you may put a breakpoint here and examine the values*/
	then = now;        /* save the current counter value for next calculation*/
	dista = (diff*10)/30/2/2;
	if (dista<1000){dist = dista;}
	angulo = (acos(1/dist)*180)/3.1416;
}
void DisplayM (void){
	LCD_command(1); /* clear display */
	delayUs(500);
	LCD_data('D'); /* write the word */
	LCD_data('i');
	LCD_data('s');
	LCD_data('t');
	LCD_data(' ');
	ntochar(dist);

	LCD_command(0xC0); /* clear display */
	LCD_data('A');
	LCD_data('n');
	LCD_data('g');
	LCD_data('S');
	LCD_data('h');
	LCD_data('o');
	LCD_data('o');
	LCD_data('t');
	LCD_data(' ');
	ntochar(angulo);
}
void measure(void) {
	calculo();
	DisplayM();
}
void delayUs(int n)
{
	int i; int j;
	for(i = 0 ; i < n; i++) {
		for(j = 0; j < 8; j++);
	}
}
