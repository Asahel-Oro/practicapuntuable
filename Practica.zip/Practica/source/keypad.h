/*
 * keypad.h
 *
 *  Created on: Nov 2, 2019
 *      Author: Asahel Orozco B
 */

#ifndef KEYPAD_H_
#define KEYPAD_H_



void keypad_init(void);
char keypad_getkey(void);
void nums (double key);
void alnums(double key);
void cn(void);
void key(void);

#endif /* KEYPAD_H_ */
