#include   <MKL25Z4.H>
#include   <stdio.h>
#include   <math.h>
#include   <stdlib.h>
#include   <ticket.h>
#include   <Lcd.h>
#include   <keypad.h>
#include   <ultrasonico.h>
#include   <matriz.h>

int increment(void);
double t1;
int ggmm;

int main (void){
	initMat();
	init_ultra();
	LCD_init();
	while (1){
		if(ggmm<=1){
			MatrixMWrite("AY");
			MatrixMWrite("Nani");
			ggmm+=1;}
		//ticketime(500);
		if(ggmm<240 && ggmm>2){
			measure();
			ggmm++;}
		if(ggmm>=240){
			clear();
			LCD_Write("Asahel 100% ");
			Rightscall ();
			delayMs(200);
			Leftscall();
			delayMs(400);
			clear();
			LCD_Write("A tu edad? ");
			ggmm+=1;
			if(ggmm==360){ggmm=0;}
		}
	}
}




