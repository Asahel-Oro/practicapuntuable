/*
 * matriz.h
 *
 *  Created on: Nov 9, 2019
 *      Author: Asahel Orozco B
 */

#ifndef MATRIZ_H_
#define MATRIZ_H_

void MatMovRW(char oraora1[100]);
void MatMovLW(char oraora1[100]);
void MatrixMWrite(char oraora1[100]);

void A(void);
void S(void);
void A(void);
void H(void);
void E(void);
void L(void);
void B(void);
void C(void);
void D(void);
void F(void);
void G(void);
void I(void);
void J(void);
void K(void);
void M(void);
void N(void);
void O(void);
void P(void);
void Q(void);
void R(void);
void T(void);
void U(void);
void V(void);
void W(void);
void X(void);
void Y(void);
void Z(void);

void cero(void);
void one(void);
void two(void);
void three(void);
void four(void);
void five(void);
void six(void);
void seven(void);
void eight(void);
void nine(void);


void Al(void);
void Sl(void);
void Hl(void);
void El(void);
void Ll(void);
void Bl(void);
void Cl(void);
void Dl(void);
void Fl(void);
void Gl(void);
void Il(void);
void Jl(void);
void Kl(void);
void Ml(void);
void Nl(void);
void Ol(void);
void Pl(void);
void Ql(void);
void Rl(void);
void Tl(void);
void Ul(void);
void Vl(void);
void Wl(void);
void Xl(void);
void Yl(void);
void Zl(void);

void cerol(void);
void onel(void);
void twol(void);
void threel(void);
void fourl(void);
void fivel(void);
void sixl(void);
void sevenl(void);
void eightl(void);
void ninel(void);





#endif /* MATRIZ_H_ */
