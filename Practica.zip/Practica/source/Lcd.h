/*
 * Lcd.h
 *
 *  Created on: Nov 2, 2019
 *      Author: Asahel Orozco B
 */

#ifndef LCD_H_
#define LCD_H_

void LCD_init(void);
void LCD_nibble_write(unsigned char data, unsigned char control);
void LCD_command(unsigned char command);
void LCD_data(unsigned char data);
void LCD_Write(char c[32]);

void delayMs(int n);
void ntochar (int s);
void numtolcd (int n);
void Home (void);
void cursor (void);
void clear (void);
void blink (void);
void Noblink (void);
void CursorSc (void);
void Rightscall (void);
void Leftscall (void);
void Display (void);
void Cposition(int x, int y);
#endif /* LCD_H_ */
