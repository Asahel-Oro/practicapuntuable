/*
 * ultrasonico.h
 *
 *  Created on: Nov 8, 2019
 *      Author: Asahel Orozco B
 */

#ifndef ULTRASONICO_H_
#define ULTRASONICO_H_


void     delayUs(int n);
void     measure(void);
void 	 init_ultra (void);
void     cal (void);
void     DisplayM (void);
void     calculo (void);

#endif /* ULTRASONICO_H_ */
