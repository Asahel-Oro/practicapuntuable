/*
 * keypad.c
 *
 *  Created on: Nov 4, 2019
 *      Author: Asahel Orozco B
 */

#include <MKL25Z4.H>
#include <stdio.h>
#include <stdlib.h>
#include <keypad.h>
#include <Lcd.h>

int menu,result;
int r1=0,y,Fa=0;
int userin = 0, mastain = 0;
int u1,u2,u3,u4,ms1,n3=0,n4;
int h1,m1,s1,h2,m2,s2,h3,m3,s3,h4,m4,s4;
int hour, minute, second, move,w;

void keypad_init(void){
	SIM->SCGC5 |= 0x0800; /* enable clock to Port C */
	PORTC->PCR[0] = 0x103; /* make PTD0 pin as GPIO and enable pullup*/
	PORTC->PCR[1] = 0x103; /* make PTD1 pin as GPIO and enable pullup*/
	PORTC->PCR[2] = 0x103; /* make PTD2 pin as GPIO and enable pullup*/
	PORTC->PCR[3] = 0x103; /* make PTD3 pin as GPIO and enable pullup*/
	PORTC->PCR[4] = 0x103; /* make PTD4 pin as GPIO and enable pullup*/
	PORTC->PCR[5] = 0x103; /* make PTD5 pin as GPIO and enable pullup*/
	PORTC->PCR[6] = 0x103; /* make PTD6 pin as GPIO and enable pullup*/
	PORTC->PCR[7] = 0x103; /* make PTD7 pin as GPIO and enable pullup*/
	PTD->PDDR = 0x0F; /* make PTD7-0 as input pins */
}
char keypad_getkey(void){
	int row, col;
	const char row_select[] = {0x01, 0x02, 0x04, 0x08}; /* one row is active */
	/* check to see any key pressed */
	PTC->PDDR |= 0x0F; /* enable all rows */
	PTC->PCOR = 0x0F;
	delayMs(2); /* wait for signal return */
	col = PTC->PDIR & 0xF0; /* read all columns */
	PTC->PDDR = 0; /* disable all rows */
	if (col == 0xF0)
		return 0; /* no key pressed */

	for (row = 0; row < 4; row++)
	{ PTC->PDDR =
			0; /* disable all rows */
	PTC->PDDR |= row_select[row]; /* enable one row */
	PTC->PCOR = row_select[row]; /* drive the active row low */
	delayMs(2); /* wait for signal to settle */
	col = PTC->PDIR & 0xF0; /* read all columns */
	if (col != 0xF0) break; /* if one of the input is low, some key
is pressed. */
	}
	PTC->PDDR = 0; /* disable all rows */
	if (row == 4)
		return 0; /* if we get here, no key is pressed */
	/* gets here when one of the rows has key pressed, check which column it is
	 */
	if (col == 0xE0) return row * 4 + 1; /* key in column 0 */
	if (col == 0xD0) return row * 4 + 2; /* key in column 1 */
	if (col == 0xB0) return row * 4 + 3; /* key in column 2 */
	if (col == 0x70) return row * 4 + 4; /* key in column 3 */
	return 0; /* just to be safe */
}
void cn(void){
	switch (n3){
	case 1: n4=y;break;
	case 2: n4=((n4*10)+y);break;
	case 3: n4=((n4*10)+y);break;
	case 4: n4=((n4*10)+y);break;
	case 5: n4=y; n3=1; Fa++; break;
	}
}

void nums(double key){

	if(key==1){
		printf("%i\n",key);
		LCD_data('1');
		y=1;
		n3++;
		delayMs(80);
		cn();
	}

	if(key==2){
		printf("%i\n",key);
		LCD_data('2');
		y=2;
		n3++;
		delayMs(80);
		cn();

	}
	if(key==3){
		printf("%i\n",key);
		LCD_data('3');
		y=3;
		n3++;
		delayMs(80);
		cn();

	}
	if(key==4){
		printf("+\n");
		printf("%i\n",key);
		LCD_data('4');
		y=4;
		n3++;
		delayMs(80);
		cn();

	}
	if(key==5){
		printf("4\n");
		printf("%i\n",key);
		LCD_data('4');
		y=4;
		n3++;
		delayMs(80);
		cn();

	}
	if(key==6){
		printf("5\n");
		printf("%i\n",key);
		LCD_data('5');
		y=5;
		n3++;
		delayMs(80);
		cn();

	}
	if(key==7){
		printf("6\n");
		printf("%i\n",key);
		LCD_data('6');
		y=6;
		n3++;
		delayMs(80);
		cn();

	}
	if(key==8){
		printf("-\n");
		printf("%i\n",key);
		LCD_data('6');
		y=6;
		n3++;
		delayMs(80);
		cn();

	}
	if(key==9){
		printf("7\n");
		printf("%i\n",key);
		LCD_data('7');
		y=7;
		n3++;
		delayMs(80);
		cn();
	}
	if(key==10){
		printf("8\n");
		printf("%i\n",key);
		LCD_data('8');
		y=8;
		n3++;
		delayMs(80);
		cn();

	}
	if(key==11){
		printf("9\n");
		printf("%i\n",key);
		LCD_data('9');
		y=9;
		n3++;
		delayMs(80);
		cn();

	}
	if(key==12){
		printf("*\n");
		printf("%i\n",key);
		LCD_data('C');
		delayMs(80);
	}
	if(key==13){
		printf("*\n");
		printf("%i\n",key);
		LCD_data('=');
		delayMs(80);
	}
	if(key==14){
		printf("0\n");
		printf("%i\n",key);
		LCD_data('0');
		y=14;
		n3++;
		delayMs(80);
		cn();

	}
	if(key==15){
		printf("%i\n",key);
		LCD_command(1);
		delayMs(80);
	}
	if(key==16){
		printf("/\n");
		printf("%i\n",key);
		LCD_data('/');
		delayMs(80);
	}
}
void mode(void){
	unsigned char key;
	keypad_init();

		key = keypad_getkey();
		LCD_Write("Uno=Alfanumerico");
		LCD_Write("Dos=numerico");
		//		switch(key){
		//		case 1: nums();break;
		//	case 2: alnums();break;
		//		default: key=1; break;
		//		}
}
void alnums(double key){
	int t =key;
	switch(t){
	case 1:
		LCD_data('A'); r1++;
		if (r1==1){LCD_data('B');}
		if (r1==2){LCD_data('C');r1=0;}
	}

}

