/*
 * ticket t.c
 *
 *  Created on: Nov 2, 2019
 *      Author: Asahel Orozco B
 */
#include   <MKL25Z4.H>
#include   <stdio.h>
#include   <ticket.H>
#include   <Lcd.H>
#include   <keypad.H>

int v;
int Co;
double time;

void time_init(void){
}
void ticketime (double t1){
	__disable_irq(); /* global disable IRQs */
	//keypad_init();
	LCD_init();

	t1= t1/1000000;
	time = t1*20970000/16-1;
	Co=t1*1000000;

	SIM->SCGC5 |= 0x400; /* enable clock to Port B */
	PORTB->PCR[18] = 0x100; /* make PTB18 pin as GPIO */
	PORTB->PCR[19] = 0x100; /* make PTB18 pin as GPIO */
	PTB->PDDR |= 0x40000; /* make PTB18 as output pin */
	PTB->PDDR |= 0x80000;

	SysTick->LOAD = time; /* reload with number of clocks per second*/
	SysTick->CTRL = 3; /* enable SysTick interrupt, use system clock/16 */
	__enable_irq(); /* global enable interrupt */
}
void SysTick_Handler(void) {
	if (v<=Co){increment();}
}
int increment (void){
	return v++;
}

