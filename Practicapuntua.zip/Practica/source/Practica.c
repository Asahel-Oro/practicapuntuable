
#include   <MKL25Z4.H>
#include   <stdio.h>
#include   <ticket.H>
#include   <Lcd.H>
#include   <keypad.H>

int increment(void);
int t1=0;

int main (){
	LCD_init();
	while (1){

//		clear();
		ticketime(5000);
		LCD_Write("Asahel 100% ");
	    Rightscall ();
	    delayMs(200);
	    Leftscall();
	    delayMs(400);
	    clear();
	    LCD_Write("A tu edad? ");

		if (v==50000){
			PTB->PTOR = 0x40000;
			v=0;
		}
	}
}



