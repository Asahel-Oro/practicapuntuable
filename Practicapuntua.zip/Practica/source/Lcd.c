/*
 * Lcd.c
 *
 *  Created on: Nov 2, 2019
 *      Author: Asahel Orozco B
 */

#include <MKL25Z4.H>
#include <Lcd.h>

#define RS 1 /* BIT0 mask */
#define RW 2 /* BIT1 mask */
#define EN 4 /* BIT2 mask */

void LCD_init(void) {
	SIM->SCGC5 |= 0x1000; /* enable clock to Port D */
	PORTD->PCR[0] = 0x100; /* make PTD0 pin as GPIO */
	PORTD->PCR[1] = 0x100; /* make PTD1 pin as GPIO */
	PORTD->PCR[2] = 0x100; /* make PTD2 pin as GPIO */
	PORTD->PCR[4] = 0x100; /* make PTD4 pin as GPIO */
	PORTD->PCR[5] = 0x100; /* make PTD5 pin as GPIO */
	PORTD->PCR[6] = 0x100; /* make PTD6 pin as GPIO */
	PORTD->PCR[7] = 0x100; /* make PTD7 pin as GPIO */
	PTD->PDDR |= 0xF7; /* make PTD7-4, 2, 1, 0 as output pins */
	delayMs(30); /* initialization sequence */
	LCD_nibble_write(0x30, 0);
	delayMs(10);
	LCD_nibble_write(0x30, 0);
	delayMs(1);
	LCD_nibble_write(0x30, 0);
	delayMs(1);
	LCD_nibble_write(0x20, 0); /* use 4-bit data mode */
	delayMs(1);
	LCD_command(0x28); /* set 4-bit data, 2-line, 5x7 font */
	LCD_command(0x06); /* move cursor right */
	LCD_command(0x01); /* clear screen, move cursor to home */
	LCD_command(0x0F); /* turn on display, cursor blinking */
}
void LCD_nibble_write(unsigned char data, unsigned char control){
	data &= 0xF0; /* clear lower nibble for control */
	control &= 0x0F; /* clear upper nibble for data */
	PTD->PDOR = data | control; /* RS = 0, R/W = 0 */
	PTD->PDOR = data | control | EN; /* pulse E */
	delayMs(0);
	PTD->PDOR = data;
	PTD->PDOR = 0;
}
void LCD_command(unsigned char command){
	LCD_nibble_write(command & 0xF0, 0); /* upper nibble first */
	LCD_nibble_write(command << 4, 0); /* then lower nibble */
	if (command < 4)
		delayMs(4); /* commands 1 and 2 need up to 1.64ms */
	else
		delayMs(1); /* all others 40 us */
}
void LCD_data(unsigned char data){
	LCD_nibble_write(data & 0xF0, RS); /* upper nibble first */
	LCD_nibble_write(data << 4, RS); /* then lower nibble */
	delayMs(1);
}
void numtolcd (int n){
	if(n==16){
		n=0;
	}
	int i = 0;
	char c[32] = {0};
	itoa(n, c, 10);
	for(i = 0; c[i] !='\0'; i ++){
		LCD_data(c[i]);
	}
}
void delayMs(int n) {
	int i;
	SysTick->LOAD = 41940 - 1;
	SysTick->CTRL = 0x5; /* Enable the timer and choose sysclk as the clock source */
	for(i = 0; i < n; i++) {
		while((SysTick->CTRL & 0x10000) == 0) /* wait until the COUTN flag is set */
		{ }
	}
	SysTick->CTRL = 0; /* Stop the timer (Enable = 0) */
}
void LCD_Write(char a[16]){
	for(int o=0; a[o]!='\0'; o++){
		LCD_data(a[o]);
		//if(c[o] == '\0'){
//			switch(c[o]){
//			case " H":LCD_command(0x2);break;
//			case " Cursor":LCD_command(0xE); break;
//			case " Clear":LCD_command(1);LCD_command(0x80);break;
//			case " Blink":LCD_command(0xF);break;
//			case " NoBlink": LCD_command(0xC);break;
//			case " CursorSc": LCD_command(0x14);break;
//			case " Rightscall":LCD_command(0x1C);break;
//			case " Leftcall":LCD_command(0x18);break;
//			case " Display": LCD_command(0xC);break;
//			}
			//}
	}
}
void Home (void){
	LCD_command(0x2);
}
void cursor (void){
	LCD_command(0xE);
}
void clear (void){
	LCD_command(1);
	LCD_command(0x80);
}
void blink (void){
	LCD_command(0xF);
}
void Noblink (void){
	LCD_command(0xC);
}
void CursorSc (void){
	LCD_command(0x14);
}
void Rightscall (void){
	LCD_command(0x1C);
}
void Leftscall (void){
	LCD_command(0x18);
}
void Display (void){
	LCD_command(0xC);
}


